﻿namespace Xcalibur.NativeMethods.Events
{
    public struct POINT
    {
        public long x;
        public long y;
    }
}
