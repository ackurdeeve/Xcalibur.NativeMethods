﻿namespace Xcalibur.NativeMethods.Monitors
{
    public static class MonitorPostion
    {
        public const uint MONITOR_MONITOR_DEFAULTTONULL = 0x00000000;
        public const uint MONITOR_MONITOR_DEFAULTTOPRIMARY = 0x00000001;
        public const uint MONITOR_DEFAULTTONEAREST = 0x00000002;
    }
}
