﻿namespace Xcalibur.NativeMethods.Windows
{
    public static class LockSetForeground
    {
        public static uint LSFW_LOCK = 1;
        public static uint LSFW_UNLOCK = 2;
    }
}
