﻿namespace Xcalibur.NativeMethods.Windows
{
    public static class FlashWindow
    {
        public static uint FLASHW_STOP = 0;
        public static uint FLASHW_CAPTION = 1;
        public static uint FLASHW_TRAY = 2;
        public static uint FLASHW_ALL = 3;
        public static uint FLASHW_TIMER = 4;
        public static uint FLASHW_TIMERNOFG = 12;
    }
}
