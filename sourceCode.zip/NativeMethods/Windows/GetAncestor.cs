﻿namespace Xcalibur.NativeMethods.Windows
{
    public static class GetAncestor
    {
        public static int GA_PARENT = 1;
        public static int GA_ROOT = 2;
        public static int GA_ROOTOWNER = 3;
    }
}
