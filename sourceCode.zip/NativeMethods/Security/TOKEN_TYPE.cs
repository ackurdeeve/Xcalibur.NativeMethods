﻿namespace Xcalibur.NativeMethods.Security
{
    /// <summary>
    /// Token type.
    /// </summary>
    public enum TOKEN_TYPE : int
    {
        TokenPrimary = 1,
        TokenImpersonation = 2
    }
}
